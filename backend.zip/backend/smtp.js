const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(cors());

app.post('/send-email', async (req, res) => {
    const { name, email, phone, message } = req.body;
 
    try {
        const transporter = nodemailer.createTransport({
            host: 'hasimovtabriz.com.tr',
            port: 465,
            secure: true,
            auth: {
                user: 'admin@hasimovtabriz.com.tr',
                pass: '3865606rt.',
            },
            tls: {
                rejectUnauthorized: false,
            },
        });
        const info = await transporter.sendMail({
            from: 'admin@hasimovtabriz.com.tr',
            to: `tebosh57@gmail.com`,
            subject: 'Hashimov Tabriz',
            html: `
                <div style="font-family: 'Arial', sans-serif; background-color: #f8f8f8; padding: 20px; text-align: center;">
                    <h1 style="color: #333; margin-bottom: 20px; font-size: 28px; font-weight: bold;">Kontakt</h1>
                    <div style="border: 2px solid #333; padding: 20px; background-color: #fff; border-radius: 10px;">
                        <h2 style="color: #333; margin-bottom: 10px; font-size: 24px;">Ad: ${name}</h2>
                        <h3 style="color: #333; margin-bottom: 10px; font-size: 20px;">E-posta: ${email}</h3>
                        <h4 style="color: #333; margin-bottom: 10px; font-size: 18px;">Telefon: ${phone}</h4>
                        <p style="color: #333; font-size: 20px; margin-top: 10px;">Mesaj: ${message}</p>
                        <img src="https://static.vecteezy.com/system/resources/previews/003/659/087/non_2x/t-white-alphabet-letter-black-circle-company-business-logo-icon-design-corporate-vector.jpg" alt="Resim" style="max-width: 100%; height: auto; margin-top: 20px; border-radius: 5px;">
                    </div>
                </div>
            `,
        });

        console.log("Message sent: " + info.messageId);

        const info1 = await transporter.sendMail({
            from: 'admin@hasimovtabriz.com.tr',
            to: email,
            subject: 'Hashimov Tabriz',
            html: `
                <div style="font-family: 'Arial', sans-serif; background-color: #f8f8f8; padding: 20px; text-align: center;">
                    <h1 style="color: #333; margin-bottom: 20px; font-size: 20px; font-weight: bold;"><a href="hasimovtabriz.com.tr">hasimovtabriz.com.tr</a></h1>
                    <div style="border: 2px solid #333; padding: 20px; background-color: #fff; border-radius: 10px;">
                        <h2 style="color: #333; margin-bottom: 10px; font-size: 24px;">Hello ${name}</h2>
                        <p style="color: #333; font-size: 20px; margin-top: 10px;">We will contact you as soon as possible.</p>
                      <a href="hasimovtabriz.com.tr">  <img src="https://static.vecteezy.com/system/resources/previews/003/659/087/non_2x/t-white-alphabet-letter-black-circle-company-business-logo-icon-design-corporate-vector.jpg" alt="Resim" style="max-width: 100%; height: auto; margin-top: 20px; border-radius: 5px;"></a>
                    </div>
                </div>
            `,
        });

        console.log("Message Sent: " + info1.messageId);

        res.send("E-posta gönderildi.");
    } catch (error) {
        console.log(error);
        res.status(500).send("Server Error.");
    }
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
